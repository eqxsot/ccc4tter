package com.example.messenger;

public interface ResponseCallBack {
    void onResponse(String response);
}
